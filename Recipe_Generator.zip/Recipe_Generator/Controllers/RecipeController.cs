﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Recipe_Generator.Data;
using Recipe_Generator.Models;
using Recipe_Generator.DTO;
using AutoMapper;

namespace Recipe_Generator.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RecipeController : ControllerBase
    {

        private readonly RecipeContext _context;
        private readonly IMapper _mapper;
        private readonly IWebHostEnvironment _environment;

        public RecipeController(RecipeContext context, IMapper mapper , IWebHostEnvironment environment)
        {
            _context = context;
            _mapper = mapper;
            _environment = environment;
        }
        [HttpGet]
        public async Task<IActionResult> GetAllRecipes()
        {
            List<Recipe> recipesList = await _context.Recipes.Include(c => c.Category).ToListAsync();
            if (recipesList != null && recipesList.Count > 0)
            {
                recipesList.ForEach(item =>
                {
                    item.Image = GetImagebyProduct(item.Code);
                });
            }
            else
            {
                return new List<Recipe>();
            }
            return recipesList;
           // return Ok(recipesList);
        }
        [NonAction]
        private string GetFilePath(string RecipeImage)
        {
            return this._environment.WebRootPath + "\\Uploads\\recipes\\" + RecipeImage;
        }
        [HttpPost("UploadImage")]
        public async Task<ActionResult> UploadImage() {
            bool Results = false;
            try
            {
                var _uploadedfiles = Request.Form.Files;
                foreach (IFormFile source in _uploadedfiles)
                {
                    string Filename = source.FileName;
                    string Filepath = GetFilePath(Filename);

                    if (!System.IO.Directory.Exists(Filepath))
                    {
                        System.IO.Directory.CreateDirectory(Filepath);
                    }

                    string imagepath = Filepath + "\\image.png";

                    if (System.IO.File.Exists(imagepath))
                    {
                        System.IO.File.Delete(imagepath);
                    }
                    using (FileStream stream = System.IO.File.Create(imagepath))
                    {
                        await source.CopyToAsync(stream);
                        Results = true;
                    }


                }
            }
            catch (Exception ex)
            {

            }
            return Ok(Results);
        }

    
    [NonAction]
    private string GetImagebyProduct(string RecipeImage)
    {
        string ImageUrl = string.Empty;
        string HostUrl = "https://localhost:7118/";
        string Filepath = GetFilePath(RecipeImage);
        string Imagepath = Filepath + "\\image.png";
        if (!System.IO.File.Exists(Imagepath))
        {
            ImageUrl = HostUrl + "/uploads/common/noimage.png";
        }
        else
        {
            ImageUrl = HostUrl + "/uploads/Product/" + RecipeImage + "/image.png";
        }
        return ImageUrl;

    }

    [HttpGet("{id:int}" , Name = "GetOneRecipe")]
        public ActionResult GetRecipe(int id)
        {
            RecipeWithCategoryNameDTO RecipeDTO = new RecipeWithCategoryNameDTO();
            if (id != null || id != 0)
            {
                Recipe recipe = _context.Recipes.Include(c => c.Category).FirstOrDefault(r => r.Id == id);
                if (recipe.Category.CategoryName != null)
                {
                    RecipeDTO.CategoryName = recipe.Category.CategoryName;
                    RecipeDTO.Description = recipe.Description;
                    RecipeDTO.RecipeName = recipe.Name;
                    RecipeDTO.PrepareTime = recipe.PrepareTime;
                    RecipeDTO.Id = recipe.Id;
                }
            }
            return Ok(RecipeDTO);
        }
        [HttpPost]
        public ActionResult CreateRecipe(Recipe recipe)
        {
            if (ModelState.IsValid == true)
            {
                context.Recipes.Add(recipe);
                context.SaveChanges();
                string url = Url.Link("GetOneRecipe", new { id = recipe.Id });
                return Created(url, recipe);
            }
            return BadRequest(ModelState);
        }
    }
}
