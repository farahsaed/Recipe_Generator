﻿
using Microsoft.EntityFrameworkCore;
using Recipe_Generator.Models;
namespace Recipe_Generator.Data
{
    public class RecipeContext :DbContext
    {
        public RecipeContext  (){}
        public RecipeContext(DbContextOptions options):base(options){ }

        public DbSet<Category> Categories { get; set; }

        public DbSet<Recipe> Recipes { get; set; }
    }
}
