﻿namespace Recipe_Generator.Models
{
    public class Admin
    {
    }
}
